#include "Plataforma.h"
#include "Renderer.h"

std::vector<Plataforma> PlataformaHandler::plataformas;

void PlataformaHandler::agregarPlataforma(float x, float y, float ancho, float alto, float r, float g, float b) {
    plataformas.push_back({x, y, ancho, alto, r, g, b});
}

void PlataformaHandler::renderizarPlataformas() {
    for (const Plataforma& p : plataformas) {
        Renderer::dibujarPlataforma({p.x, p.y, p.ancho, p.alto, p.r, p.g, p.b});
    }
}

bool PlataformaHandler::chequearColisionJugadorConPlataforma( const Rectangulo& jugador,Plataforma& plataformaColisionada) {
   
   // Crear una copia modificable
    Rectangulo jugadorModificado = jugador;
	for (auto& plataforma : plataformas) {
        // Verificar si el jugador est� colisionando con la plataforma
        if (jugador.x + jugador.ancho / 2 > plataforma.x - plataforma.ancho / 2 &&
            jugador.x - jugador.ancho / 2 < plataforma.x + plataforma.ancho / 2) {
            
            
            // Comprobar colisi�n por la parte inferior
            if (jugador.y + jugador.alto / 2 > plataforma.y - plataforma.alto / 2 &&
                jugador.y < plataforma.y) {  // Jugador debajo de la plataforma
                plataformaColisionada = plataforma;
                return true;
            }
			// Comprobar colisi�n por la parte superior
            if (jugador.y - jugador.alto / 2 < plataforma.y + plataforma.alto / 2 &&
                jugador.y > plataforma.y) {  // Jugador encima de la plataforma
                plataformaColisionada = plataforma;
                return true;
            }

        }
    }

    return false;  // No hubo colisi�n
    
}

